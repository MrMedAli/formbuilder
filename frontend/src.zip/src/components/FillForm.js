import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Box,
  TextField,
  Button,
  Select,
  MenuItem,
  Typography,
  Paper,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import authService from "../services/authService";

const FillForm = () => {
  const [forms, setForms] = useState([]);
  const [selectedFormId, setSelectedFormId] = useState("");
  const [form, setForm] = useState(null);
  const [response, setResponse] = useState({});
  const [savedResponses, setSavedResponses] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchForms();
  }, []);

  useEffect(() => {
    if (selectedFormId) {
      fetchForm(selectedFormId);
    }
  }, [selectedFormId]);

  const fetchForms = async () => {
    try {
      const headers = authService.getAuthHeader();
      const response = await axios.get("http://localhost:8000/api/forms/", {
        headers,
      });
      setForms(response.data);
    } catch (error) {
      console.error("Failed to fetch forms:", error);
      if (error.response && error.response.status === 403) {
        navigate("/");
      }
    }
  };

  const fetchForm = async (formId) => {
    try {
      const headers = authService.getAuthHeader();
      const response = await axios.get(
        `http://localhost:8000/api/forms/${formId}/`,
        { headers }
      );
      setForm(response.data);
      setResponse(
        Object.keys(response.data.form_structure).reduce((acc, key) => {
          const fieldType = response.data.form_structure[key];
          acc[key] = fieldType.type === "array" ? [{}] : "";
          return acc;
        }, {})
      );
      fetchSavedResponses(formId);
    } catch (error) {
      console.error("Failed to fetch form:", error);
      if (error.response && error.response.status === 403) {
        navigate("/");
      }
    }
  };

  const fetchSavedResponses = async (formId) => {
    try {
      const headers = authService.getAuthHeader();
      const response = await axios.get(
        `http://localhost:8000/api/responses/?form=${formId}`,
        { headers }
      );
      setSavedResponses(response.data);
    } catch (error) {
      console.error("Failed to fetch saved responses:", error);
      if (error.response && error.response.status === 403) {
        navigate("/");
      }
    }
  };

  const handleChange = (field, value, index = null, subField = null) => {
    if (index !== null) {
      const updatedArray = [...response[field]];
      if (subField) {
        updatedArray[index] = {
          ...updatedArray[index],
          [subField]: value,
        };
      } else {
        updatedArray[index] = value;
      }
      setResponse({
        ...response,
        [field]: updatedArray,
      });
    } else {
      setResponse({
        ...response,
        [field]: value,
      });
    }
  };

  const addArrayItem = (field) => {
    setResponse({
      ...response,
      [field]: [...response[field], {}],
    });
  };

  const handleSave = async () => {
    try {
      const headers = authService.getAuthHeader();
      await axios.post(
        `http://localhost:8000/api/forms/${selectedFormId}/submit/`,
        { response_data: response },
        { headers }
      );
      alert("Form saved successfully");
      fetchSavedResponses(selectedFormId);
    } catch (error) {
      console.error("Failed to save form:", error);
      if (error.response && error.response.status === 403) {
        navigate("/");
      } else {
        alert("Failed to save form");
      }
    }
  };

  const handleDownload = () => {
    const dataStr =
      "data:text/json;charset=utf-8," +
      encodeURIComponent(JSON.stringify(response));
    const downloadAnchorNode = document.createElement("a");
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `${form.title}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const renderFields = (structure, parentKey = "") => {
    return Object.keys(structure).map((key) => {
      const fieldType = structure[key];
      const compositeKey = parentKey ? `${parentKey}.${key}` : key;
      if (typeof fieldType === "string") {
        return (
          <Grid item xs={12} key={compositeKey}>
            <TextField
              fullWidth
              label={key}
              type={fieldType}
              value={response[compositeKey] || ""}
              onChange={(e) => handleChange(compositeKey, e.target.value)}
              required
            />
          </Grid>
        );
      } else if (fieldType.type === "array") {
        return (
          <Grid item xs={12} key={compositeKey}>
            <Typography variant="subtitle1">{key}:</Typography>
            {response[compositeKey] &&
              response[compositeKey].map((item, index) => (
                <Box key={index} sx={{ mb: 2 }}>
                  {typeof fieldType.items === "object" ? (
                    renderFields(fieldType.items, `${compositeKey}.${index}`)
                  ) : (
                    <TextField
                      fullWidth
                      type={fieldType.items}
                      value={item || ""}
                      onChange={(e) =>
                        handleChange(compositeKey, e.target.value, index)
                      }
                      required
                    />
                  )}
                </Box>
              ))}
            <Button
              variant="outlined"
              onClick={() => addArrayItem(compositeKey)}
            >
              + Add
            </Button>
          </Grid>
        );
      } else {
        return (
          <Grid item xs={12} key={compositeKey}>
            <Typography variant="subtitle1">{key}:</Typography>
            <Box sx={{ pl: 2 }}>{renderFields(fieldType, compositeKey)}</Box>
          </Grid>
        );
      }
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Fill Form
      </Typography>
      <Paper sx={{ p: 2, mb: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Select
              fullWidth
              value={selectedFormId}
              onChange={(e) => setSelectedFormId(e.target.value)}
              displayEmpty
            >
              <MenuItem value="" disabled>
                Select a form
              </MenuItem>
              {forms.map((form) => (
                <MenuItem key={form.id} value={form.id}>
                  {form.title}
                </MenuItem>
              ))}
            </Select>
          </Grid>
          {form && (
            <>
              <Grid item xs={12}>
                <form>
                  <Grid container spacing={2}>
                    {renderFields(form.form_structure)}
                  </Grid>
                  <Box sx={{ mt: 2 }}>
                    <Button
                      variant="contained"
                      onClick={handleSave}
                      sx={{ mr: 1 }}
                    >
                      Save Form
                    </Button>
                    <Button variant="outlined" onClick={handleDownload}>
                      Download JSON
                    </Button>
                  </Box>
                </form>
              </Grid>
              {savedResponses.length > 0 && (
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Saved Responses
                  </Typography>
                  <TableContainer component={Paper}>
                    <Table>
                      <TableHead>
                        <TableRow>
                          {Object.keys(savedResponses[0].response_data).map(
                            (key) => (
                              <TableCell key={key}>{key}</TableCell>
                            )
                          )}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {savedResponses.map((savedResponse, index) => (
                          <TableRow key={index}>
                            {Object.values(savedResponse.response_data).map(
                              (value, idx) => (
                                <TableCell key={idx}>{value}</TableCell>
                              )
                            )}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Grid>
              )}
            </>
          )}
        </Grid>
      </Paper>
    </Box>
  );
};

export default FillForm;
