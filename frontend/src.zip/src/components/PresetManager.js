import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  TextField,
  Button,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  IconButton,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import authService from "../services/authService";

const API_URL = "http://localhost:8000/api/presets/";

const PresetManager = () => {
  const [presets, setPresets] = useState([]);
  const [selectedPreset, setSelectedPreset] = useState(null);
  const [name, setName] = useState("");
  const [presetStructure, setPresetStructure] = useState("");

  useEffect(() => {
    fetchPresets();
  }, []);

  const fetchPresets = async () => {
    try {
      const response = await axios.get(API_URL, {
        headers: authService.getAuthHeader(),
      });
      setPresets(response.data);
    } catch (error) {
      console.error("Failed to fetch presets:", error);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const presetData = {
        name,
        preset_structure: JSON.parse(presetStructure),
      };
      if (selectedPreset) {
        await axios.put(`${API_URL}${selectedPreset.id}/`, presetData, {
          headers: authService.getAuthHeader(),
        });
      } else {
        await axios.post(API_URL, presetData, {
          headers: authService.getAuthHeader(),
        });
      }
      fetchPresets();
      setSelectedPreset(null);
      setName("");
      setPresetStructure("");
    } catch (error) {
      console.error("Failed to save preset:", error);
    }
  };

  const handleDelete = async (presetId) => {
    try {
      await axios.delete(`${API_URL}${presetId}/`, {
        headers: authService.getAuthHeader(),
      });
      fetchPresets();
    } catch (error) {
      console.error("Failed to delete preset:", error);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>
        Preset Manager
      </Typography>
      <Paper sx={{ p: 2, mb: 2 }}>
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            sx={{ mb: 2 }}
          />
          <TextField
            fullWidth
            label="Preset Structure (JSON)"
            value={presetStructure}
            onChange={(e) => setPresetStructure(e.target.value)}
            required
            multiline
            rows={4}
            sx={{ mb: 2 }}
          />
          <Button type="submit" variant="contained" color="primary">
            {selectedPreset ? "Update Preset" : "Create Preset"}
          </Button>
        </form>
      </Paper>

      <Typography variant="h5" gutterBottom>
        Existing Presets
      </Typography>
      <List>
        {presets.map((preset) => (
          <ListItem
            key={preset.id}
            secondaryAction={
              <Box>
                <IconButton
                  edge="end"
                  aria-label="edit"
                  onClick={() => {
                    setSelectedPreset(preset);
                    setName(preset.name);
                    setPresetStructure(
                      JSON.stringify(preset.preset_structure, null, 2)
                    );
                  }}
                >
                  <EditIcon />
                </IconButton>
                <IconButton
                  edge="end"
                  aria-label="delete"
                  onClick={() => handleDelete(preset.id)}
                >
                  <DeleteIcon />
                </IconButton>
              </Box>
            }
          >
            <ListItemText primary={preset.name} />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default PresetManager;
